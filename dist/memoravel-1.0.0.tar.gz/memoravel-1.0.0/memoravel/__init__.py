# memoravel/__init__.py

from .memoravel import Memoravel  # Importa a classe principal

__all__ = ["Memoravel"]
